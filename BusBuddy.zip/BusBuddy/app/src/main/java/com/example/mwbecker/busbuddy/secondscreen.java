package com.example.mwbecker.busbuddy;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class secondscreen extends AppCompatActivity {
    public  int i;
    TextView tv;
    public String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondscreen);
        Button okayBtn = (Button) findViewById(R.id.submitBtn);
        okayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent q = new Intent(secondscreen.this, accountCreated.class);
                startActivity(q);
            }
        });

        final Button passBtn = (Button) findViewById(R.id.passBtn);
        final Button drivBtn = (Button) findViewById(R.id.drivBtn);
        passBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv = (TextView) findViewById(R.id.tv);
                tv.setText("Passenger");
                tv.setTextColor(Color.parseColor("#FF6172B6"));
                passBtn.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

            }
        });
        drivBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv = (TextView) findViewById(R.id.tv);
                tv.setText("Driver");
                tv.setTextColor(Color.parseColor("#FFFAC549"));
                drivBtn.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
                passBtn.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

            }
        });
    }}


